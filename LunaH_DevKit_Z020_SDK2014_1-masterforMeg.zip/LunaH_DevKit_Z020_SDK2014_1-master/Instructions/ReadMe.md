#Instructions for Z020, GitHub, DevKit, and GUI Use

Please contact Graham (gstoddard@rmdinc.com) or Erik (ejohnson@rmdinc.com) for any issues with the GUI.